package it.unibas.aziende.persistenza;

import it.unibas.aziende.modello.Archivio;
import it.unibas.aziende.modello.Azienda;
import it.unibas.aziende.modello.Dipendente;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.Month;

public class DAOArchivioMock implements IDAOArchivio {
    
    @Override
    public Archivio carica(InputStream stream) throws DAOException {
        Archivio archivio = new Archivio();
        Azienda a1 = new Azienda("A1", "azienda 1", "Potenza");
        a1.getDipendenti().add(new Dipendente("LTMMHL", "Michele", "Altamura", LocalDate.of(2024, Month.MAY, 13), "Basilicata"));
        a1.getDipendenti().add(new Dipendente("LMTMTT", "Mattia", "Lomuto", LocalDate.of(2022, Month.SEPTEMBER, 15), "Lombardia"));
        a1.getDipendenti().add(new Dipendente("RSSFRC", "Francesca", "Rossi", LocalDate.of(2019, Month.FEBRUARY, 8), "Umbria"));
        archivio.getAziende().add(a1);
        Azienda a2 = new Azienda("A2", "azienda 2", "Milano");
        a2.getDipendenti().add(new Dipendente("MCCMRA", "Mauro", "Moccia", LocalDate.of(2023, Month.APRIL, 23), "Basilicata"));
        a2.getDipendenti().add(new Dipendente("LPRMHL", "Michele", "Lopardi", LocalDate.of(2021, Month.OCTOBER, 21), "Marche"));
        a2.getDipendenti().add(new Dipendente("FRRGND", "Giandomenico", "Ferrara", LocalDate.of(2019, Month.FEBRUARY, 8), "Umbria"));
        a2.getDipendenti().add(new Dipendente("FRCLRA", "Laura", "Franco", LocalDate.of(2020, Month.MAY, 14), "Lombardia"));
        archivio.getAziende().add(a2);
        Azienda a3 = new Azienda("A3", "azienda 3", "Roma");
        a3.getDipendenti().add(new Dipendente("MCCMRA", "Mauro", "Moccia", LocalDate.of(2018, Month.APRIL, 23), "Basilicata"));
        a3.getDipendenti().add(new Dipendente("LPRMHL", "Michele", "Lopardi", LocalDate.of(2015, Month.OCTOBER, 21), "Marche"));
        a3.getDipendenti().add(new Dipendente("FRRGND", "Giandomenico", "Ferrara", LocalDate.of(2019, Month.FEBRUARY, 8), "Liguria"));        
        archivio.getAziende().add(a3);
        return archivio;
    }

    @Override
    public void salva(Archivio archivio, OutputStream stream) throws DAOException {
        throw new DAOException("Operazione non supportata");
    }

}
