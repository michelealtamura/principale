package it.unibas.aziende.modello;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;

@Getter
public class Archivio {
    
    private final List<Azienda> aziende = new ArrayList<>();
    
    public List<Azienda> cercaPerDataAssunzione(LocalDate data) {
        List<Azienda> aziendeTrovate = new ArrayList<>();
        for (Azienda azienda : aziende) {
            if(azienda.contieneDipendentiPerData(data)) {
                aziendeTrovate.add(azienda);
            }
        }
        return aziendeTrovate;
    }
    
    public String calcolaRegioneFrequente() {
        Map<String, Integer> mappaRegioni = new HashMap<>();
        for (Azienda azienda : aziende) {
            for (Dipendente dipendente : azienda.getDipendenti()) {
                Integer occorrenze = mappaRegioni.getOrDefault(dipendente.getRegioneResidenza(), 0);
                mappaRegioni.put(dipendente.getRegioneResidenza(), occorrenze + 1);
            }                      
        }
        String regione = null;
        for (String string : mappaRegioni.keySet()) {
            if(regione == null || mappaRegioni.get(string) > mappaRegioni.get(regione)) {
                regione = string;
            }
        }
        return regione;
    }
    
    public void gestisciDipendenti(String regione) {
        for (Azienda azienda : aziende) {
            azienda.rimuoviPerRegione(regione);          
        }
    }

}
