package it.unibas.aziende.vista;

import it.unibas.aziende.modello.Azienda;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public class ModelloTabellaAziende extends AbstractTableModel {
    
    private List<Azienda> aziende;
    
    public void setAziende(List<Azienda> aziende) {
        this.aziende = aziende;
    }

    @Override
    public int getRowCount() {
        if(aziende == null) {
            return 0;
        }
        return aziende.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Azienda riga = aziende.get(rowIndex);
        if(columnIndex == 0) {
            return riga.getPartitaIva();
        }
        if(columnIndex == 1) {
            return riga.getDenominazione();
        }
        if(columnIndex == 2) {
            return riga.getCitta();
        }
        return riga.getDipendenti().size();
    }

    @Override
    public String getColumnName(int column) {
        if(column == 0) {
            return "Partita iva";
        }
        if(column == 1) {
            return "Denominazione";
        }
        if(column == 2) {
            return "Città";
        }
        return "Numero dipendenti";
    }
    
    public void aggiornaContenuto() {
        super.fireTableDataChanged();
    }
    
    

}
