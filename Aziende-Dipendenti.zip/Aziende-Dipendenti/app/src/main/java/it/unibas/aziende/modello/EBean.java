package it.unibas.aziende.modello;

public enum EBean {
    ARCHIVIO,
    AZIENDE_TROVATE,
    AZIENDA_SELEZIONATA
    
}
