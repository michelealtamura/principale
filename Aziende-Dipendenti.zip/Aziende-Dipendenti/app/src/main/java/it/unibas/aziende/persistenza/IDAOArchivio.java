package it.unibas.aziende.persistenza;

import it.unibas.aziende.modello.Archivio;
import java.io.InputStream;
import java.io.OutputStream;


public interface IDAOArchivio {

    Archivio carica(InputStream stream) throws DAOException;

    void salva(Archivio archivio, OutputStream stream) throws DAOException;
    
}
