package it.unibas.aziende.controllo;

import it.unibas.aziende.Applicazione;
import it.unibas.aziende.modello.Archivio;
import it.unibas.aziende.modello.Azienda;
import it.unibas.aziende.modello.EBean;
import it.unibas.aziende.vista.ModelloTabellaAziende;
import it.unibas.aziende.vista.VistaPrincipale;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JOptionPane;
import lombok.Getter;

@Getter
public class ControlloPrincipale {
    
    private Action azioneCerca = new AzioneCerca();
    private Action azioneElimina = new AzioneElimina();
    private Action azioneMostraDettagli = new AzioneMostraDettagli();
    
    class AzioneCerca extends AbstractAction {
        
        public AzioneCerca() {
            this.putValue(Action.NAME, "Cerca");
            this.putValue(Action.SHORT_DESCRIPTION, "Cerca per data");
            this.setEnabled(false);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            VistaPrincipale vistaPrincipale = Applicazione.getInstance().getVistaPrincipale();
            int giorno = (Integer) vistaPrincipale.getComboGiorno().getSelectedItem();
            int mese = vistaPrincipale.getComboMese().getSelectedIndex() + 1;
            int anno = (int) vistaPrincipale.getComboAnno().getSelectedItem();
            String errori = convalida(giorno, mese, anno);
            if(!errori.isEmpty()) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori(errori);
                return;
            }
            Archivio archivio = (Archivio) Applicazione.getInstance().getModello().getBean(EBean.ARCHIVIO);
            List<Azienda> aziendeTrovate = archivio.cercaPerDataAssunzione(LocalDate.of(anno, mese, giorno));
            Collections.sort(aziendeTrovate);
            Applicazione.getInstance().getModello().putBean(EBean.AZIENDE_TROVATE, aziendeTrovate);
            ModelloTabellaAziende modello = (ModelloTabellaAziende) vistaPrincipale.getTabellaAziende().getModel();
            modello.setAziende(aziendeTrovate);
            modello.aggiornaContenuto();
        }  
        
        public String convalida(int giorno, int mese, int anno) {
            StringBuilder sb = new StringBuilder();
            try {
                LocalDate.of(anno, mese, giorno);
            } catch (Exception e) {
                sb.append("Data scorretta");
            }
            return sb.toString();
        }
    }
    
    class AzioneElimina extends AbstractAction {
        
        public AzioneElimina() {
            this.putValue(Action.NAME, "Elimina");
            this.putValue(Action.SHORT_DESCRIPTION, "Elimina l'azienda selezionata");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int riga = Applicazione.getInstance().getVistaPrincipale().getTabellaAziende().getSelectedRow();
            if(riga == -1) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori("Nessuna riga selezionata");
                return;
            }
            List<Azienda> aziende = (List<Azienda>) Applicazione.getInstance().getModello().getBean(EBean.AZIENDE_TROVATE);
            if(Applicazione.getInstance().getFrame().mostraFinestraConferma("Confermi di voler eliminare l'azienda?") != JOptionPane.YES_OPTION) {
                return;
            }
            aziende.remove(riga);
            Collections.sort(aziende);
            ModelloTabellaAziende modello = (ModelloTabellaAziende) Applicazione.getInstance().getVistaPrincipale().getTabellaAziende().getModel();
            modello.setAziende(aziende);
            modello.aggiornaContenuto();          
        }      
    }
    
    class AzioneMostraDettagli extends AbstractAction {
        
        public AzioneMostraDettagli() {
            this.putValue(Action.NAME, "Modifica");
            this.putValue(Action.SHORT_DESCRIPTION, "Modifica azienda");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            int riga = Applicazione.getInstance().getVistaPrincipale().getTabellaAziende().getSelectedRow();
            if(riga == -1) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori("Nessuna riga selezionata");
                return;
            }
            List<Azienda> aziende = (List<Azienda>) Applicazione.getInstance().getModello().getBean(EBean.AZIENDE_TROVATE);
            Applicazione.getInstance().getModello().putBean(EBean.AZIENDA_SELEZIONATA, aziende.get(riga));
            Applicazione.getInstance().getVistaDettagli().visualizza();
            ModelloTabellaAziende modello = (ModelloTabellaAziende) Applicazione.getInstance().getVistaPrincipale().getTabellaAziende().getModel();
            Collections.sort(aziende);
            modello.setAziende(aziende);
            modello.aggiornaContenuto(); 
        }      
    }

}
