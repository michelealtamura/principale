package it.unibas.aziende.modello;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class Dipendente {
    
    private String codiceFiscale;;
    private String nome;
    private String cognome;
    private LocalDate dataAssunzione;
    private String regioneResidenza;

}
