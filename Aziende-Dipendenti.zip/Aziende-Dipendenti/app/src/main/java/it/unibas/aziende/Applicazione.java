package it.unibas.aziende;

import it.unibas.aziende.controllo.ControlloDettagli;
import it.unibas.aziende.controllo.ControlloMenu;
import it.unibas.aziende.controllo.ControlloPrincipale;
import it.unibas.aziende.modello.Modello;
import it.unibas.aziende.persistenza.DAOArchivioMock;
import it.unibas.aziende.persistenza.IDAOArchivio;
import it.unibas.aziende.vista.Frame;
import it.unibas.aziende.vista.VistaDettagli;
import it.unibas.aziende.vista.VistaPrincipale;
import javax.swing.SwingUtilities;
import lombok.Getter;

@Getter
public class Applicazione {
    
    private static final Applicazione singleton = new Applicazione();
    
    private Applicazione() {
    }
    
    public static Applicazione getInstance() {
        return singleton;
    }
    
    public void inizializza() {
        frame = new Frame();
        vistaPrincipale = new VistaPrincipale();
        vistaDettagli = new VistaDettagli(frame);
        vistaDettagli.inizializza();
        vistaPrincipale.inizializza();
        frame.inizializza();
    }
    
    private IDAOArchivio daoArchivio = new DAOArchivioMock();
    private Modello modello = new Modello();
    private ControlloPrincipale controlloPrincipale = new ControlloPrincipale();
    private ControlloMenu controlloMenu = new ControlloMenu();
    private ControlloDettagli controlloDettagli = new ControlloDettagli();
    private Frame frame;
    private VistaPrincipale vistaPrincipale;
    private VistaDettagli vistaDettagli;
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Applicazione.getInstance().inizializza();
        });
    }

}
