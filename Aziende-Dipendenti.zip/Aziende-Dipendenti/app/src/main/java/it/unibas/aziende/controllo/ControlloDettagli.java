package it.unibas.aziende.controllo;

import it.unibas.aziende.Applicazione;
import it.unibas.aziende.modello.Azienda;
import it.unibas.aziende.modello.EBean;
import it.unibas.aziende.vista.VistaDettagli;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import lombok.Getter;

@Getter
public class ControlloDettagli {
    
    private Action azioneModifica = new AzioneModifica();
    
    class AzioneModifica extends AbstractAction {
        
        public AzioneModifica() {
            this.putValue(Action.NAME, "Modifica");
            this.putValue(Action.SHORT_DESCRIPTION, "Modifica azienda selezionataa");
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            VistaDettagli vistaDettagli = Applicazione.getInstance().getVistaDettagli();
            String partitaIva = vistaDettagli.getCampoPartitaIva().getText();
            String denominazione = vistaDettagli.getCampoDenominazione().getText();
            String citta = vistaDettagli.getCampoCitta().getText();
            String errori = convalida(partitaIva, denominazione, citta);
            if(!errori.isEmpty()) {
                Applicazione.getInstance().getFrame().mostraMessaggioErrori(errori);
                return;
            }
            Azienda aziendaSelezionata = (Azienda) Applicazione.getInstance().getModello().getBean(EBean.AZIENDA_SELEZIONATA);
            aziendaSelezionata.setCitta(citta);
            aziendaSelezionata.setDenominazione(denominazione);
            aziendaSelezionata.setPartitaIva(partitaIva);
            vistaDettagli.ripulisciCampi();
            vistaDettagli.setVisible(false);
        }   
        
        public String convalida(String partitaIva, String denominazione, String citta) {
            StringBuilder sb = new StringBuilder();
            if(partitaIva.isEmpty()) {
                sb.append("Inserire la partita iva");
            }
            if(partitaIva.length() != 6) {
                sb.append("ILunghezza partita iva scorretta");
            }
            if(denominazione.isEmpty()) {
                sb.append("Inserire una denominazione");
            }
            if(citta.isEmpty()) {
                sb.append("Inserire una città");
            }
            return sb.toString();
        }
    }

}
