package it.unibas.aziende.controllo;

import it.unibas.aziende.Applicazione;
import it.unibas.aziende.modello.Archivio;
import it.unibas.aziende.modello.EBean;
import it.unibas.aziende.persistenza.DAOException;
import it.unibas.aziende.persistenza.IDAOArchivio;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.KeyStroke;
import lombok.Getter;

@Getter
public class ControlloMenu {
    
    private Action azioneEsci = new AzioneEsci();
    private Action azioneCarica = new AzioneCarica();
    
    
    class AzioneEsci extends AbstractAction {
        
        public AzioneEsci() {
            this.putValue(Action.NAME, "Esci");
            this.putValue(Action.SHORT_DESCRIPTION, "Esci dall'applicazione");
            this.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);
            this.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("ctrl alt E"));
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }      
    }
    
    class AzioneCarica extends AbstractAction {
        
        public AzioneCarica() {
            this.putValue(Action.NAME, "Carica");
            this.putValue(Action.SHORT_DESCRIPTION, "Carica archivio");
            this.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
            this.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("ctrl alt C"));
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            Archivio archivio;
            IDAOArchivio dAOArchivio = Applicazione.getInstance().getDaoArchivio();
            try {
                archivio = dAOArchivio.carica(null);
                Applicazione.getInstance().getModello().putBean(EBean.ARCHIVIO, archivio);
                Applicazione.getInstance().getFrame().mostraMessaggioInformazioni("Archivio caricato correttamente");
                Applicazione.getInstance().getControlloPrincipale().getAzioneCerca().setEnabled(true);
            } catch (DAOException ex) {
            }
        }      
    }

}
