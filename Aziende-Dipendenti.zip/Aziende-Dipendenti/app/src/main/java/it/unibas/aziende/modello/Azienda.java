package it.unibas.aziende.modello;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@AllArgsConstructor
@Setter
public class Azienda implements Comparable<Azienda>{
    
    private String partitaIva;
    private String denominazione;
    private String citta;
    private final List<Dipendente> dipendenti = new ArrayList<>();
    
    public boolean contieneDipendentiPerData(LocalDate data) {
        for (Dipendente dipendente : dipendenti) {
            if(dipendente.getDataAssunzione().isBefore(data)) {
                return true;
            }          
        }
        return false;
    }

    @Override
    public int compareTo(Azienda o) {
        return o.dipendenti.size() - this.dipendenti.size();
    }

    public void rimuoviPerRegione(String regione) {
        Iterator<Dipendente> it = dipendenti.iterator();
        while(it.hasNext()) {
            Dipendente dipendente = it.next();
            if(dipendente.getRegioneResidenza().equals(regione)) {
                it.remove();
            }
        }
    }

}
