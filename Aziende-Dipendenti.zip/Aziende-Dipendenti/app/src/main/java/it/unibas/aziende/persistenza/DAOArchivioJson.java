package it.unibas.aziende.persistenza;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import it.unibas.aziende.modello.Archivio;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DAOArchivioJson implements IDAOArchivio {

    @Override
    public Archivio carica(InputStream stream) throws DAOException {
        try {
            GsonBuilder builder = new GsonBuilder();
            builder.registerTypeAdapter(LocalDate.class, new LocalDateAdapter());
            Gson gson = builder.create();
            Archivio archivio = gson.fromJson(new InputStreamReader(stream), Archivio.class);
            return archivio;
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            try {
                stream.close();
            } catch (Exception ex) {
            }
        }
    }

    @Override
    public void salva(Archivio archivio, OutputStream stream) throws DAOException {
        PrintWriter flusso = null;
        try {
            flusso = new PrintWriter(stream);
            GsonBuilder builder = new GsonBuilder();
            builder.registerTypeAdapter(LocalDate.class, new LocalDateAdapter());
            builder.setPrettyPrinting();
            Gson gson = builder.create();
            String stringaJson = gson.toJson(archivio);
            flusso.print(stringaJson);
        } catch (Exception e) {
            throw new DAOException(e);
        } finally {
            if (flusso != null) {
                flusso.close();
            }
        }
    }

    class LocalDateAdapter implements JsonSerializer<LocalDate>, JsonDeserializer<LocalDate> {

        @Override
        public JsonElement serialize(LocalDate t, Type type, JsonSerializationContext jsc) {
            return new JsonPrimitive(t.format(DateTimeFormatter.ISO_DATE));
        }

        @Override
        public LocalDate deserialize(JsonElement je, Type type, JsonDeserializationContext jdc) throws JsonParseException {
            return LocalDate.parse(je.getAsString(), DateTimeFormatter.ISO_DATE);
        }

    }

}
