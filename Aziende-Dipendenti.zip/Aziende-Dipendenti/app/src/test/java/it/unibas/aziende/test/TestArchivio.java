package it.unibas.aziende.test;

import it.unibas.aziende.modello.Archivio;
import it.unibas.aziende.persistenza.DAOArchivioJson;
import it.unibas.aziende.persistenza.DAOArchivioMock;
import it.unibas.aziende.persistenza.DAOException;
import it.unibas.aziende.persistenza.IDAOArchivio;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.Month;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@Slf4j
public class TestArchivio {

    private Archivio archivio;

    @BeforeEach
    public void setUp() {
        IDAOArchivio daoArchivio = new DAOArchivioMock();
        try {
            archivio = daoArchivio.carica(null);
        } catch (DAOException e) {
        }
    }

    @Test
    public void testRicercaData() {
        Assertions.assertEquals(3, archivio.cercaPerDataAssunzione(LocalDate.now()).size());
        Assertions.assertEquals(1, archivio.cercaPerDataAssunzione(LocalDate.of(2018, Month.DECEMBER, 23)).size());
    }

    @Test
    public void testGestisci() {
        Assertions.assertEquals("Basilicata", archivio.calcolaRegioneFrequente());
        archivio.gestisciDipendenti(archivio.calcolaRegioneFrequente());
        Assertions.assertEquals(2, archivio.getAziende().get(0).getDipendenti().size());
        Assertions.assertEquals(3, archivio.getAziende().get(1).getDipendenti().size());
        Assertions.assertEquals(2, archivio.getAziende().get(2).getDipendenti().size());
    }

    @Test
    public void testSalvaJson() {
        IDAOArchivio daoArchivioJson = new DAOArchivioJson();
        try {
            daoArchivioJson.salva(archivio, new FileOutputStream("./src/test/resources/archivio-mock.json"));
        } catch (Exception e) {
            Assertions.fail();
        }
    }

    @Test
    public void testCaricaJson() {
        IDAOArchivio daoArchivioJson = new DAOArchivioJson();
        Archivio archivio;
        try {
            InputStream stream = TestArchivio.class.getResourceAsStream("./src/test/resources/archivio-mock.json");
            log.debug("{}", stream);
            archivio = daoArchivioJson.carica(stream);
            Assertions.assertEquals(3, archivio.getAziende().size());
        } catch (Exception e) {
            log.error("{}", e.getLocalizedMessage());
            Assertions.fail();
        }
    }
}
